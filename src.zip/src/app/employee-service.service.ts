import { Injectable } from '@angular/core';
import { empty } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmployeeServiceService {

  firstname: string;
  

  constructor() { }
   
  emp = [
    {id:1,name:"Manish",salary:12342,city:"Pune",age:22,
    dob:new Date("JAN 20,1997"),pan:"bcsjf5555E",mobile:"8765674543"},
    {id:2,name:"Suresh",salary:11342,city:"Pune",age:23,
    dob:new Date("JAN 20,1997"),pan:"bcsjf5555E",mobile:"9987567654"},
    {id:3,name:"Yash",salary:11342,city:"Pune",age:24,
    dob:new Date("JAN 20,1997"),pan:"bcsjf5555E",mobile:"9987567654"},
    {id:6,name:"Ravi",salary:11342,city:"Pune",age:23,
    dob:new Date("JAN 20,1997"),pan:"bcsjf5555E",mobile:"9987567654"},
    {id:4,name:"Bhavik",salary:11342,city:"Pune",age:23,
    dob:new Date("JAN 20,1997"),pan:"bcsjf5555E",mobile:"9987567654"},
    {id:5,name:"Rushabh",salary:11342,city:"Pune",age:23,
    dob:new Date("JAN 20,1997"),pan:"bcsjf5555E",mobile:"9987567654"}


];
}