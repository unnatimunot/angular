import { Injectable } from '@angular/core';
import { empty } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmployeeServiceService {

  firstname: string;
  

  constructor() { }
   
  emp = [
    {id:102,name:"Manish",salary:12342,city:"Pune",age:23,gender:1,
    dob:new Date("May 31,1982"),pan:"pcxam9834D",mobile:"8765674543"},
    {id:101,name:"Suresh",salary:11342,city:"Pune",age:23,gender:1,
    dob:new Date("May 31,1982"),pan:"pcxam9834D",mobile:"9987567654"},
    {id:103,name:"Yash",salary:11342,city:"Pune",age:23,gender:1,
    dob:new Date("May 31,1982"),pan:"pcxam9834D",mobile:"9987567654"},
    {id:106,name:"Ravi",salary:11342,city:"Pune",age:23,gender:1,
    dob:new Date("May 31,1982"),pan:"pcxam9834D",mobile:"9987567654"},
    {id:104,name:"Bhavik",salary:11342,city:"Pune",age:23,gender:1,
    dob:new Date("May 31,1982"),pan:"pcxam9834D",mobile:"9987567654"},
    {id:107,name:"Mohan",salary:11342,city:"Pune",age:23,gender:1,
    dob:new Date("May 31,1982"),pan:"pcxam9834D",mobile:"9987567654"},
    {id:105,name:"Rushabh",salary:11342,city:"Pune",age:23,gender:1,
    dob:new Date("May 31,1982"),pan:"pcxam9834D",mobile:"9987567654"}


];
}