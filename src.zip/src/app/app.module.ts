import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { BasicComponent } from './basic/basic.component';
import { FormsModule } from '@angular/forms'
import { EmployeeServiceService } from './employee-service.service';
import { PipedemoComponent } from './pipedemo/pipedemo.component';

@NgModule({
  declarations: [
    AppComponent,
    BasicComponent,
    PipedemoComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [EmployeeServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
