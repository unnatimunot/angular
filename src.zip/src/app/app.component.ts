import { Component } from '@angular/core';
import { EmployeeServiceService } from './employee-service.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'My First App';
  course = [{"c1":"JAVA","c2":"SPRING","c3":"SPRING BOOT","c4":"TESTING"}];
  col="red"
  emp={};
  fname: string;
  lname: string;
  
  constructor( private ser:EmployeeServiceService){}
  ngOnInit()
  {
   this.emp=this.ser.emp.sort(); 
  }
  
  show()
  {
    alert("hi")
  }
}
